<?php
session_start();
require_once('backend/dbconn.php');

if (!isset($_SESSION['customerID'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['fooditemID'])) {
    $fooditemID = $_POST['fooditemID'];
    $customerID = $_SESSION['customerID'];
    
    $quantity = 1;  

    $query = "INSERT INTO cart (quantity, customerID, fooditemID) VALUES (:quantity, :customerID, :fooditemID)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':customerID', $customerID);
    $stmt->bindParam(':fooditemID', $fooditemID);

    if ($stmt->execute()) {
            $_SESSION['itemAdded'] = true;
            $redirectURL = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
            header('Location: ' . $redirectURL);
            exit();
    } else {
        echo "Error: Could not add to cart.";
    }
} else {
    die("Error: Food item not specified.");
}
?>

