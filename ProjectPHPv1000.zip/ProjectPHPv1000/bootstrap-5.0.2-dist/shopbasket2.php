<div class="container">
  <section class="intro">
    <div class="bg-image h-100" style="background-color: #f5f7fa;">
      <div class="mask d-flex align-items-center h-100">
        <div class="container">
          <div class="table-responsive">
            <div class="card">
              <div class="card-body p-0">
                <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative; height: 700px">
                  <table class="table table-striped mb-0">
                    <thead style="background-color: #002d72;">
                      <tr>
                        <th class="text-center">Product</th>
                        <th class="text-center">Product Name</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Quantity</th>  
                        <th class="text-center">Total</th>  
                        <th class="text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        require_once('dbconn.php');
                        try {
                          $stmt = $conn->prepare("SELECT * FROM basket");
                          $stmt->execute();
                          foreach ($stmt->fetchAll() as $row) {
                      ?>
                        <tr>
                          <td class="text-center">
                            <?php
                              $img_data = base64_encode($row['basketimg']);
                              $img_type = 'image/jpeg'; 
                            ?>
                            <img src="data:<?php echo $img_type; ?>;base64,<?php echo $img_data; ?>" width="200" height="200">
                          </td>
                          <td class="text-center"><?php echo $row['baskettitle']; ?></td>
                          <td class="text-center"><?php echo $row['basketprice']; ?></td>

                          <td class="text-center">
                            <form id="update-form-<?php echo $row['basketid']; ?>" action="basketupdate.php?redirect=<?php echo basename($_SERVER['PHP_SELF']) ?>" method="POST">
                                <input type="hidden" name="basketid" value="<?php echo $row['basketid']; ?>">
                                <input type="number" name="quantity" style="width: 80px; border-radius: 10px;" min="1" max="50" value="<?php echo $row['basketquantity']; ?>">
                            </td>
                            <td class="text-center"><?php echo $row['baskettotal']; ?></td>
                            <td class="text-center">
                                <button type="submit" style="border: none; background-color: transparent; color: blue;">
                                    <i class="bi bi-pencil-square" style="font-size: 24px;"></i>
                                </button>
                                <script>
                                    function showConfirmation(basketid) {
                                        Swal.fire({
                                            title: 'Are you sure?',
                                            text: 'You are about to delete this record!',
                                            icon: 'warning',
                                            showCancelButton: true,
                                            confirmButtonText: 'Yes, delete it!',
                                            cancelButtonText: 'No, cancel',
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = 'basketdelete.php?basketid=' + basketid + '&confirm_delete=yes';
                                            }
                                        });
                                    }

                                    // Generate the JavaScript code for the Sweet Alert
                                    const form<?php echo $row['basketid']; ?> = document.getElementById('update-form-<?php echo $row['basketid']; ?>');
                                    form<?php echo $row['basketid']; ?>.addEventListener('submit', function(event) {
                                        event.preventDefault();
                                        Swal.fire({
                                            title: 'Success!',
                                            text: 'The Quantity has been Updated.',
                                            icon: 'success'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                form<?php echo $row['basketid']; ?>.submit();
                                            }
                                        });
                                    });
                                </script>
                                <a href="#" onclick="showConfirmation('<?php echo $row['basketid']; ?>')">
                                    <i class="bi bi-trash-fill" style="font-size: 24px; color: red;"></i>
                                </a>
                            </form>
                        </td>

                        </tr>
                        <?php
                          }
                        } catch(PDOException $e) {
                          echo "ERROR: " . $e->getMessage();
                        }
                            $conn = null;
                            ?>
                     </tbody>     
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>