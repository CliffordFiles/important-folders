<?php
require_once('dbconn.php');

try {
    $sql = "UPDATE basket SET basketquantity = :basketquantity, baskettotal = basketprice * :basketquantity WHERE basketid = :basketid";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':basketquantity', $_POST['quantity'], PDO::PARAM_INT);
    $stmt->bindParam(':basketid', $_POST['basketid'], PDO::PARAM_STR);
    $stmt->execute();
    header("Location: ".$_SERVER['HTTP_REFERER']."?success=true");
} catch(PDOException $e) {
    echo "ERROR: ". $e->getMessage();
}

$conn = null;
?>
