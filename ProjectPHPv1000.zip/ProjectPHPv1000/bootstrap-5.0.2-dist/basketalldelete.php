<?php
require_once('dbconn.php');

try {
    $sql = "Truncate table basket";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    header('Location: ' . $_SERVER['HTTP_REFERER']);
} catch(PDOException $e) {
    echo "ERROR: ". $e->getMessage();
}

$conn = null;
?>
