<?php
require_once('dbconn.php');
$sql = "SELECT SUM(baskettotal) AS total FROM basket";
$result = $conn->query($sql);
$total = $result->fetchColumn();

echo '$ ' . ($total ? $total : '0');

$conn = null;
?>
