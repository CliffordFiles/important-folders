<?php
require_once('dbconn.php');
try{
    $sql = "SELECT * FROM registration Where regID = :ad_regID";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':ad_regID', $_GET['regID'], PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
catch(PDOException $e){
    echo "ERROR: ".$e->getMessage();
}

$conn = null;
?>

<!DOCTYPE html>
<html>

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/light.css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
   <link rel="stylesheet" href="Allcss/login.css">
   <title>USER - EDIT</title>
</head>

<body>
   <a style="border: 2px solid #7AB5B6; border-radius: 5px; text-decoration: none; padding: 5px 10px; font-weight: bold; background: #23c483; color: #324B4B;"
      href='display_users.php'>LIST
      OF USERS</a>
      <div class="container">
        <div class="row">
   <h2 style="text-align: center;">UPDATE USER'S INFORMATION</h2>
   <form action="update.php" method="get">
      <div class="box">
            <div class="login_container" style="border: solid 3px; border-color:green">
      <h3 for="regID">REGISTRATION ID: <?php echo $row['regID']; ?></h3>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="hidden" name="regID" size="20"
         value="<?php echo $row['regID']; ?>" readonly>
         <label for="newfirstname">New Firstname:</label>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="text" name="newfirstname" size="20"
         value="<?php echo $row['firstname'];?>">
         <label for="newlastname">New Lastname:</label>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="text" name="newlastname" size="20"
         value="<?php echo $row['lastname'];?>">

         <label for="newemail">New Email:</label>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="text" name="newemail" size="20"
         value="<?php echo $row['email'];?>">

      <label for="newusername">New Username:</label>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="text" name="newusername" size="20"
         value="<?php echo $row['username'];?>">
      <label for="newpassword">New Password:</label>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="text" name="newpassword" size="20"
         value="<?php echo $row['password'];?>">
         <label for="newpassword2">Confirm New Password:</label>
      <input style="width: 95%; background: white; margin-bottom: 20px;" type="text" name="newpassword2" size="20"
         value="<?php echo $row['password2'];?>">
         <div class="input-field">
      <input type="submit" class= "submit"
         value="Update User" style="background-color: rgb(23, 104, 23);">
         </div>
         </div>
         </div> 
</div>
</div>
      </tr>
   </form>
</body>

</html>