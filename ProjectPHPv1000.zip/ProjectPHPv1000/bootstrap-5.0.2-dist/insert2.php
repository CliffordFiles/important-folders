<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
function checkUsername() {
    
    jQuery.ajax({
    url: "availability.php",
    data:'username='+$("#username").val(),
    type: "POST",
    success:function(data){
        $("#check-username").html(data);
    },
    error:function (){}
    });
}

function checkPassword() {
    var password = $("#password").val();
    var cpassword = $("#password2").val();
    var errors = [];

    if (password.length < 9) {
        $("#check-password").html("<span style='color:red'>Password must be at least 9 characters long.</span>");
        $("#submit").prop("disabled", true);
        return;
    }

    if (!/[A-Z]/.test(password)) {
        $("#check-password").html("<span style='color:red'>Password must contain at least 1 uppercase letter.</span>");
        $("#submit").prop("disabled", true);
        return;
    }

    if (!/[^a-zA-Z0-9]/.test(password)) {
        $("#check-password").html("<span style='color:red'>Password must contain at least 1 special character.</span>");
        $("#submit").prop("disabled", true);
        return;
    }
    if (!/[0-9]/.test(password)) {
        $("#check-password").html("<span style='color:red'>Password must contain at least 1 alphanumeric character.</span>");
        $("#submit").prop("disabled", true);
        return;
    }
    // if no error is found, show success message and enable the submit button
    $("#check-password").html("<span style='color:green'>Password is valid.</span>");
    $("#submit").prop("disabled", false);
}

function checkMobileNumber() {
    var mobilenumber = $("#mobilenumber").val();
    if (mobilenumber == '') {
        $("#check-mobile").html("");
        $("#submit").prop("disabled", true);
        return false;
    } else if (!/^09[0-9]{9}$/.test(mobilenumber)) {
        $("#check-mobile").html("<span style='color:red'>Invalid Mobile Number Format</span>");
        $("#submit").prop("disabled", true);
        return false;
    } else {
        $("#check-mobile").html("");
        $("#submit").prop("disabled", false);
        return true;
    }
}

function checkCpassword() {
    var password = $("#password").val();
    var confirmPassword = $("#password2").val();
    if (password == '' || confirmPassword == '') {
        $("#check-password2").html("");
        return false;
    } else if (password != confirmPassword) {
        $("#check-password2").html("<span style='color:red'> Passwords do not match.</span>");
        $("#submit").prop("disabled", true);
        return false;
    } else {
        $("#check-password2").html("<span style='color:green'> Passwords match.</span>");
        $("#submit").prop("disabled", false);
        return true;
    }
}

function checkEmail() {
    
    jQuery.ajax({
    url: "availability.php",
    data:'email='+$("#email").val(),
    type: "POST",
    success:function(data){
        $("#check-email").html(data);
    },
    error:function (){}
    });
}

</script>