<?php
session_start();
require_once('dbconn.php');

if (isset($_POST['submitnewpassword'])) {
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    if (empty($_POST['password']) || empty($_POST['password2'])) {
        echo "<script>alert('Please fill in all fields.');window.location.href='accounteditpassword2.php'</script>";
        exit();
    }

    if (strlen($password) < 8) {
        echo "<script>alert('Password must be at least 8 characters long.');window.location.href='accounteditpassword2.php'</script>";
        exit();
    }

    if (!preg_match('/[A-Z]/', $password)) {
        echo "<script>alert('Password must contain at least 1 uppercase letter.');window.location.href='accounteditpassword2.php'</script>";
        exit();
    }

    if (!preg_match('/[0-9]/', $password) || !preg_match('/[^a-zA-Z0-9]/', $password)) {
        echo "<script>alert('Password must contain at least 1 alphanumeric character and 1 special character.');window.location.href='accounteditpassword2.php'</script>";
        exit();
    }

    if ($password != $password2) {
        echo "<script>alert('Passwords do not match.');window.location.href='accounteditpassword2.php'</script>";
        exit();
    }

    $regID = $_SESSION['regID'];

    try {
        $sql = "UPDATE registration SET password=:password, password2=:password2 WHERE regID = :regID"; 
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':password2', $password2);
        $stmt->bindParam(':regID', $regID);
        $stmt->execute();

        $_SESSION['password'] = $password;

        echo "<script>alert('Password successfully updated!');window.location.href='loginaccsetting.php'</script>";
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
