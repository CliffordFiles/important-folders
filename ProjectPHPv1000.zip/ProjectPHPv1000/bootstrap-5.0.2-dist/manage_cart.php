<?php
session_start();
require_once('dbconn.php');

if (isset($_POST['Add_To_Cart'])) {
    $item_name = $_POST['Item_Name'];
    $item_price = $_POST['Price'];
    $item_quantity = $_POST['quantity1'];
    $basket_total = $item_price * $item_quantity; // calculate basket total
  
    // Get the image of the item from the database
    $stmt = $conn->prepare("SELECT bevimg FROM beverage WHERE bevtitle = ?");
    $stmt->bindParam(1, $item_name);
    $stmt->execute();
    $results = $stmt->fetch(PDO::FETCH_ASSOC);
    $item_image = $results['bevimg'];

    // Insert the item into the basket table
    $stmt = $conn->prepare("INSERT INTO basket (baskettitle, basketprice, basketquantity, basketimg, baskettotal) VALUES (?, ?, ?, ?, ?)");
    $stmt->bindParam(1, $item_name);
    $stmt->bindParam(2, $item_price);
    $stmt->bindParam(3, $item_quantity);
    $stmt->bindParam(4, $item_image);
    $stmt->bindParam(5, $basket_total);
    $stmt->execute();
    
    header('location: ' . $_GET['redirect']);

}
?>

<?php

if (isset($_POST['Add_To_Cart_Search'])) {
    $item_name = $_POST['Item_Name'];
    $item_price = $_POST['Price'];
    $item_quantity = $_POST['quantity1'];
    $basket_total = $item_price * $item_quantity; // calculate basket total
  
    // Get the image of the item from the database
    $stmt = $conn->prepare("SELECT bevimg FROM beverage WHERE bevtitle = ?");
    $stmt->bindParam(1, $item_name);
    $stmt->execute();
    $results = $stmt->fetch(PDO::FETCH_ASSOC);
    $item_image = $results['bevimg'];

    // Insert the item into the basket table
    $stmt = $conn->prepare("INSERT INTO basket (baskettitle, basketprice, basketquantity, basketimg, baskettotal) VALUES (?, ?, ?, ?, ?)");
    $stmt->bindParam(1, $item_name);
    $stmt->bindParam(2, $item_price);
    $stmt->bindParam(3, $item_quantity);
    $stmt->bindParam(4, $item_image);
    $stmt->bindParam(5, $basket_total);
    $stmt->execute();

    header('location: ' . $_GET['redirect']);
}
?>

<?php
if (isset($_GET['basketid']) && isset($_GET['quantity'])) {
    // Get the basketid and quantity from the URL parameters
    $basketid = $_GET['basketid'];
    $quantity = $_GET['quantity'];
    
    var_dump($quantity); // Add this line to check the value of $quantity
    
    // Update the basket quantity in the database
    $stmt = $conn->prepare("UPDATE basket SET basketquantity = :quantity WHERE basketid = :basketid");
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':basketid', $basketid);
    $stmt->execute();
    
    // Redirect the user back to the shopping cart page
    header('Location: shopbasket.php');
    exit();
}
?>



