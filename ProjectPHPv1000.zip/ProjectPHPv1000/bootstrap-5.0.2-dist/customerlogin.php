
<?php
require_once 'dbconn.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM registration WHERE username=:username AND password=:password");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();
      

    $result = $stmt->fetchAll();
    if (count($result) > 0) {

        $userstatus = $result[0]['userstatus'];

        if ($userstatus == 'blocked') {
            echo "<script>alert('Your account is blocked. Please contact the administrator.');window.location.href='login.php'</script>";
            return;
        }

        $_SESSION['username'] = $username;
        $_SESSION['regID'] = $result[0]['regID'];
        $regID = $_SESSION['regID'];

        // Fetch the rows from the basket table
        $stmt4 = $conn->prepare("SELECT * FROM basket");
        $stmt4->execute();
             
        // Iterate over the rows and insert into the basket_filter table
        while ($row = $stmt4->fetch()) {
            $baskettitle = $row['baskettitle'];
            $basketprice = $row['basketprice'];
            $basketquantity = $row['basketquantity'];
            $basketimg = $row['basketimg'];
            $baskettotal = $row['baskettotal'];
            $regID = $_SESSION['regID'];
            if (!empty($baskettitle)) {
                $stmt5 = $conn->prepare("INSERT INTO userorders (ubaskettitle, ubasketquantity, ubasketimg, ubasketprice, ubaskettotal, regID) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt5->bindParam(1, $baskettitle);
                $stmt5->bindParam(2, $basketquantity);
                $stmt5->bindParam(3, $basketimg, PDO::PARAM_LOB);
                $stmt5->bindParam(4, $basketprice);
                $stmt5->bindParam(5, $baskettotal);
                $stmt5->bindParam(6, $regID);
                $stmt5->execute();
            }
        }

        $stmt3 = $conn->prepare("TRUNCATE TABLE basket");
        $stmt3->execute();

        header("Location: loginhome.php");
        exit();

    } 
    
    else {
        echo "<script>alert('Incorrect Username & Password');window.location.href='login.php'</script>";
    }
}
