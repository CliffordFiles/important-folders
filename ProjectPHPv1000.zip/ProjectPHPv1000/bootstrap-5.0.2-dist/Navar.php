<style>
  #basketLink {
  position: relative;
  display: inline-block;
}

.basket-count {
  display: inline-block;
  position: absolute;
  top: -10px;
  right: -10px;
  background-color: #ff5c5c;
  color: white;
  border-radius: 50%;
  padding: 6px;
  font-weight: bold;
  font-size: 11px;
  line-height: 1;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
  transition: transform 0.3s ease-in-out;
}

.basket-count:hover {
  transform: scale(1.1);
  cursor: pointer;
}
</style>
<?php session_start();
 ?>
 
<div class="fixed-top">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
        <a class="navbar-brand me-2" href="#">
          <img
            class="logo"
            src="img/Logo.png"
            loading="lazy"
            onclick="location.href='home.php';"
            style="cursor: pointer;"
          />
        </a>

          <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#micon">
            <span class="navbar-toggler-icon"></span>
          </button>
          </div>

          <div class="collapse navbar-collapse " id="micon" style="margin-left: 50px;">
          <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link " aria-current="page" id="homeLink" href="home.php">HOME</a>
            </li>&nbsp;&nbsp;
            <li class="nav-item">
                <a class="nav-link" aria-current="page" id="beverageLink" href="Beverage.php">BEVERAGE</a>
              </li>&nbsp;&nbsp;
              <li class="nav-item">
                <a class="nav-link" aria-current="page" id="searchLink" href="search.php">SEARCH</a>
              </li>&nbsp;&nbsp;
              <li class="nav-item">
                <a class="nav-link" aria-current="page" id="aboutLink" href="About.php">ABOUT</a>
              </li>&nbsp;&nbsp;
              <li class="nav-item">
              <?php
              require_once('dbconn.php');

              $stmt = $conn->prepare("SELECT COUNT(*) as count FROM basket");
              $stmt->execute();
              $result = $stmt->fetch(PDO::FETCH_ASSOC);
              $count = $result['count'];
              ?>
              <a class="nav-link" aria-current="page" id="basketLink" href="shopbasket.php" style="margin-right: 50px;">
                SHOPPING BASKET 
                <?php if ($count > 0): ?>
                  <span class="basket-count"><?php echo $count; ?></span>
                <?php endif; ?>
              </a>
              </li>&nbsp;&nbsp; 

              <div class="d-flex align-items-center">
              <a href="login.php"><button type="button" class="btn btn-success me-3" style="border-radius: 10px;">
                    Login  <i class="bi bi-box-arrow-in-right"></i>
                  </button></a>
              <a href="signup.php"><button type="button" class="btn btn-success me-3" style="border-radius: 10px;">
                Sign Up  <i class="bi bi-person-add"></i>
              </button></a>
            </div>
          </div>       
        </div>
      </div>
    </nav>
</div>