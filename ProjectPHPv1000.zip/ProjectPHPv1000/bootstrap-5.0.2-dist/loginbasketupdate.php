<?php
require_once('dbconn.php');

try {
    $sql = "UPDATE userorders SET ubasketquantity = :ubasketquantity, ubaskettotal = ubasketprice * :ubasketquantity WHERE ubasketid = :ubasketid";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':ubasketquantity', $_POST['quantity'], PDO::PARAM_INT);
    $stmt->bindParam(':ubasketid', $_POST['basketid'], PDO::PARAM_STR);
    $stmt->execute();
    header("Location: ".$_SERVER['HTTP_REFERER']."?success=true");
    exit();
} catch(PDOException $e) {
    echo "ERROR: ". $e->getMessage();
}

$conn = null;
?>
