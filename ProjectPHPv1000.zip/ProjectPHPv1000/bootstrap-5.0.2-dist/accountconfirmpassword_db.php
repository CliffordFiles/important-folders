
<?php
require_once 'dbconn.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $password = $_POST['password'];
    $regID = $_SESSION['regID'];

    $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = :regID AND password = :password");
    $stmt->bindParam(':regID', $regID);
    $stmt->bindParam(':password', $password);
    $stmt->execute();
      

    $result = $stmt->fetchAll();
    if (count($result) > 0) {

        $_SESSION['password'] = $password;
        
        echo "<script>alert('Correct Password');window.location.href='accounteditpassword2.php'</script>";
    } else {
        echo "<script>alert('Incorrect Password');window.location.href='accounteditpassword.php'</script>";
    }
}
?>


