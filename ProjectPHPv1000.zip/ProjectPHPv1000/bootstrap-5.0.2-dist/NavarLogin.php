<?php
    include('customerlogin.php')
?>
<style>
  #basketLink {
  position: relative;
  display: inline-block;
}

.basket-count {
  display: inline-block;
  position: absolute;
  top: -10px;
  right: -10px;
  background-color: #ff5c5c;
  color: white;
  border-radius: 50%;
  padding: 6px;
  font-weight: bold;
  font-size: 11px;
  line-height: 1;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
  transition: transform 0.3s ease-in-out;
}

.basket-count:hover {
  transform: scale(1.1);
  cursor: pointer;
}
@media (max-width: 991px) {
  .navbar-nav .nav-link {
    margin-bottom: 10px;
  }
}
</style>
<div class="fixed-top">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand me-2" href="loginhome.php">
        <img class="logo" src="img/Logo.png" loading="lazy">
      </a>&nbsp;

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#micon">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="micon">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" id="homeLink" href="loginhome.php">HOME</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" id="beverageLink" href="loginbeverage.php">BEVERAGE</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" id="searchLink" href="loginsearch.php">SEARCH</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" id="aboutLink" href="loginAbout.php">ABOUT</a>
          </li>

          <?php
            require_once('dbconn.php');
            $regID = $_SESSION['regID'];
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM userorders where regID = :regID");
            $stmt->bindParam(':regID', $regID);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $count = $result['count'];
        ?>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" id="basketLink" href="loginshopbasket.php">
              <span class="basket-text">SHOPPING BASKET</span>
              <?php if ($count > 0): ?>
                <span class="basket-count"><?php echo $count; ?></span>
              <?php endif; ?>
            </a>
          </li>

          <li class="dropdown">
            <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border-radius: 10px; margin-bottom: 5px; margin-left:20px;">
              Welcome! <?php echo isset($_SESSION['username']) ? substr($_SESSION['username'], 0, 10) : 'Guest'; ?>
            </button>
            <div class="dropdown-menu dropdown-menu-end">
              <a class="dropdown-item" href="loginaccsetting.php">Account Settings</a>
              <a class="dropdown-item" href="loginorderhistory.php">Order History</a>
            </div>
          </li>

          <li class="nav-item">
            <a href="login.php" class="btn btn-success" style="border-radius: 10px;">
              Log-Out <i class="bi bi-person-add"></i>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</div>