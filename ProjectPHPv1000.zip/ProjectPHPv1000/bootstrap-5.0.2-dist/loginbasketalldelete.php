<?php
session_start();
require_once('dbconn.php');

try {
    $regID = $_SESSION['regID'];
    $sql = "DELETE FROM userorders WHERE regID = :regID";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':regID', $regID);
    $stmt->execute();
    header('Location: ' . $_SERVER['HTTP_REFERER']); 
} catch(PDOException $e) {
    echo "ERROR: ". $e->getMessage();
}

$conn = null;
?>
