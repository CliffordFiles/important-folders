<?php
session_start();
require_once('dbconn.php');

try {
    $sql = "DELETE FROM userorders WHERE ubasketid = :ubasketid";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':ubasketid', $_GET['ubasketid'], PDO::PARAM_STR);
    $stmt->execute();
    header('Location: ' . $_SERVER['HTTP_REFERER']);
} catch(PDOException $e) {
    echo "ERROR: ". $e->getMessage();
}

$conn = null;
?>