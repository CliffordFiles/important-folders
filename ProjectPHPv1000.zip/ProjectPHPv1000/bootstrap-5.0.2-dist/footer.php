<Style>
    .ilalum{
    background-color: rgb(230, 230, 230);
    text-align: center;
}
    .footericons i{
    margin: auto;
    width: 50%;
    padding: 30px;
    color:black (1, 92, 1);
}
hr{
    color: rgb(1, 92, 1);
}
.copyright{
    color:rgb(1, 92, 1); 
    padding-bottom: 30px;
}
.footericons a{
    text-decoration: none;
}

.footericons i{
    color:rgb(1, 92, 1)
}

</Style>

<footer>
        <div class="ilalum"><br>
            <div class ="footericons">
                <a class= "twitter" href="">
                    <i class="bi bi-twitter"></i>
                </a>
                <a href="">
                    <i class="bi bi-facebook"></i>
                </a>
                    <a href="">
                    <i class="bi bi-youtube"></i>
                </a>
                <a href="">
                    <i class="bi bi-instagram"></i>
                </a>
                <a href="">
                    <i class="bi bi-twitch"></i>
                </a>
                <a href="">
                    <i class="bi bi-github"></i>
                </a>
            </div>
        <br>
        <div class="copyright">
            &copy; Jaron_Gomez  2023
        </div>   
    </div>
    </footer>