<?php
require_once('dbconn.php');

$stmt = $conn->prepare("SELECT * FROM beverage");
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<div class="container">
  <div class="row">
    <?php foreach ($results as $row) { ?>
      <div class="col-12 col-md-6 col-lg-4 mb-4">
        <form action="loginmanage_cart.php?redirect=<?php echo basename($_SERVER['PHP_SELF']) ?>" method="POST">
        <div class="card h-100" style="border-radius: 30px; box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.2);">
          <img src='data:image/jpeg;base64,<?php echo base64_encode($row['bevimg']) ?>' alt="<?php echo $row['bevtitle'] ?>" class="card-img-top" width="400" height="400">
          <div class="card-body">
            <center>
            <h5 class="card-title"><?php echo $row['bevtitle'] ?></h5>
            <br>
            <p class="card-text mb-3"><?php echo $row['bevdesc'] ?></p>
            <h5 class="card-text">$<?php echo $row['bevprice'] ?></h5>
            <br>

              <label for="quantity">Quantity:</label>
              <input type="number" id="quantity" name="quantity1" min="1" max="50" style="border-radius: 10px;" value="1">
              <br><br>
              <button href="#!" type="submit" name="Add_To_Cart" class="btn btn-success me-3" style="border-radius: 10px; margin-left: 25px; "><i class="bi bi-basket me-2"></i>Add to Basket</button>
              <input type="hidden" name="Item_Name" value="<?php echo $row['bevtitle'] ?>">
              <input type="hidden" name="Price" value="<?php echo $row['bevprice'] ?>">        
          </div>
          </center>
        </div>
      </div>
      </form>
    <?php } ?>
  </div>
</div>