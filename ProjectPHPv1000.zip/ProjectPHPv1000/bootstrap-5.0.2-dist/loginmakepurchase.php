<?php
session_start();
require_once 'dbconn.php';

    $stmt = $conn->prepare("SELECT ubasketprice, ubasketquantity FROM userorders WHERE regID = ?");
    $stmt->bindParam(1, $_SESSION['regID']);
    $stmt->execute();

    $ubaskettotal = 0; // Initialize the total to zero

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $ubasketprice = $row['ubasketprice'];
        $ubasketquantity = $row['ubasketquantity'];
        $orderdate = date("Y-m-d H:i:s");
        $orderdelivery = date('Y-m-d H:i:s', strtotime('+1 week'));
        $orderstatus = "pending";
        
        $ubaskettotal += ($ubasketprice * $ubasketquantity); // Accumulate the total
    }

        $stmt1 = $conn->prepare("INSERT INTO usertransaction (uorderdate, uorderdeli, uordertotal, orderstatus, regID) VALUES (?, ?, ?, ?, ?)");
        $stmt1->bindParam(1, $orderdate);
        $stmt1->bindParam(2, $orderdelivery);
        $stmt1->bindParam(3, $ubaskettotal);
        $stmt1->bindParam(4, $orderstatus);
        $stmt1->bindParam(5, $_SESSION['regID']);
        $stmt1->execute();

        $stmt2 = $conn->prepare("SELECT ubaskettitle, ubasketprice, ubasketquantity, ubasketimg FROM userorders WHERE regID = ?");
        $stmt2->bindParam(1, $_SESSION['regID']);
        $stmt2->execute();

        $stmt3 = $conn->prepare("SELECT utransac_id FROM usertransaction WHERE regID = ? ORDER BY utransac_id DESC LIMIT 1");
        $stmt3->bindParam(1, $_SESSION['regID']);
        $stmt3->execute();
        $utransac_id = $stmt3->fetchColumn();

        while ($row = $stmt2->fetch()) {
        $ubaskettitle = $row['ubaskettitle'];
        $ubasketprice = $row['ubasketprice'];
        $ubasketquantity = $row['ubasketquantity'];
        $ubasketimg = $row['ubasketimg'];

        $stmt5 = $conn->prepare("INSERT INTO orderdetails (udetailtitle, udetailquantity, udetailimg, udetailprice, utransac_id) VALUES (?, ?, ?, ?, ?)");
        $stmt5->bindParam(1, $ubaskettitle);
        $stmt5->bindParam(2, $ubasketquantity);
        $stmt5->bindParam(3, $ubasketimg, PDO::PARAM_LOB);
        $stmt5->bindParam(4, $ubasketprice);
        $stmt5->bindParam(5, $utransac_id);
        $stmt5->execute();
}

    $stmt6 = $conn->prepare("DELETE FROM userorders WHERE regID = ?");
    $stmt6->bindParam(1, $_SESSION['regID']);
    $stmt6->execute();

header('Location: ' . $_SERVER['HTTP_REFERER']); 
exit();
?>