<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
   
    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <link rel="stylesheet" href="Allcss/login.css">
    <script defer src="active_link.js"></script>
    
</head>
<body>
    <?php
    include('Navar.php')
    ?>
    <br><br><br><br><br><br>
<!-- Section: Design Block -->
<section class="text-center text-lg-start">
  <style>
    .cascading-right {
      margin-right: -50px;
    }

    @media (max-width: 991.98px) {
      .cascading-right {
        margin-right: 0;
      }
    }
  </style>

<div class="container py-4">
  <div class="row g-4 align-items-center">
    <div class="col-lg-5 mb-4 mb-lg-0">
      <div class="card cascading-right shadow" style="background: hsla(0, 0%, 100%, 0.55); backdrop-filter: blur(30px); border-radius: 10px;">
        <div class="card-body p-5 text-center" style="height: 600px;"><br>
          <header>Login</header><br><br>
          <form action="customerlogin.php" method="post">
            <div class="form-outline mb-4">
              <input type="text" class="input" placeholder="Username" name="username" required>
            </div>
            <div class="form-outline mb-4">
              <input type="password" class="input" placeholder="Password" name="password" required>
            </div>
            <div class="input-field">
              <input type="submit" class="submit" value="Login" name="login">
            </div><br>
            <div class="bottom">
              <label> <a href="signup.php">Create An Account?</a></label>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div id="myCarousel" class="carousel slide shadow" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="img/fanta1.jpg" class="d-block w-100 rounded-4 shadow" alt="First slide" style="height: 600px; border-radius: 10px;">
          </div>
          <div class="carousel-item">
            <img src="img/okay.jpg" class="d-block w-100 rounded-4 shadow" alt="Second slide" style="height: 600px; border-radius: 10px;">
          </div>
          <div class="carousel-item">
            <img src="img/kk.jpg" class="d-block w-100 rounded-4 shadow" alt="Third slide" style="height: 600px; border-radius: 10px;">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>
  </div>


  <!-- Jumbotron -->
  </section><br><br><br>

     <!-- Footer -->
     <?php
      include('footer.php')
      ?>
</body>
</html>