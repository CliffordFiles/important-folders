<?php
require_once('dbconn.php');

$stmt = $conn->query("SELECT COUNT(*) FROM basket");
$count = $stmt->fetchColumn();

if ($count == 0) {
  echo 'empty';
} else {
  echo 'not empty';
}

$conn = null;
?>