<?php
require_once('dbconn.php');

$firstname = $_GET['firstname'];
$lastname = $_GET['lastname'];
$email = $_GET['email'];
$username = $_GET['username'];
$address = $_GET['address'];
$mobilenumber = $_GET['mobilenumber'];
$password = $_GET['password'];
$password2 = $_GET['password2'];


$errors = array();

if (strlen($password) < 8) {
    $errors[] = "Password must be at least 9 characters long.";
}

if (!preg_match('/[A-Z]/', $password)) {
    $errors[] = "Password must contain at least 1 uppercase letter.";
}

if (!preg_match('/[0-9]/', $password) || !preg_match('/[^a-zA-Z0-9]/', $password)) {
    $errors[] = "Password must contain at least 1 alphanumeric character and 1 special character.";
}

if ($password != $password2) {
    $errors[] = "Password and confirm password fields do not match.";
}
if (!preg_match('/^09[0-9]{9}$/', $mobilenumber)){
    $errors[] = "Invalid Mobile Number Format";
}

// Check if username already exists
$sql = "SELECT * FROM registration WHERE username=:username";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':username', $username, PDO::PARAM_STR);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $errors[] = "Username already exists. Please choose a different one.";
}


// Check if email already exists
$sql = "SELECT * FROM registration WHERE email=:email";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':email', $email, PDO::PARAM_STR);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $errors[] = "Email already exists. Please use a different one.";
}

$default_profile_picture_path = 'img/Pfp.jpg';
$profile = fopen($default_profile_picture_path, 'rb');

if (empty($errors)) {
    try {
        $sql = "INSERT INTO registration(firstname, lastname, email, username, address, mobilenumber, password, password2, profile) VALUES (:firstname, :lastname, :email, :username, :address, :mobilenumber, :password, :password2, :profile)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':firstname', $firstname, PDO::PARAM_STR);
        $stmt->bindParam(':lastname', $lastname, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->bindParam(':address', $address, PDO::PARAM_STR);
        $stmt->bindParam(':mobilenumber', $mobilenumber, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
        $stmt->bindParam(':password2', $password2, PDO::PARAM_STR);
        $stmt->bindParam(':profile', $profile, PDO::PARAM_LOB);
        $stmt->execute();
        echo "<script>alert('Sign Up Successful!');window.location.href='login.php'</script>";
    } catch(PDOException $e) {
        $errors[] = "ERROR: ". $e->getMessage();
    }
}

$conn = null;
?>

<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach ($errors as $error): ?>
    <script>alert('<?php echo $error; ?>');window.location.href='signup.php'</script>
<?php endforeach; ?>
</div>
<?php endif; ?>