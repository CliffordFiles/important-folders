<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <script defer src="active_link.js"></script>

</head>
<body>
      <!-- For Navar -->
      <?php
      include('NavarLogin.php')
      ?>
      <br><br><br><br><br><br>

  <div class="container">
    <div class="row">
        <h5 style="font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 30px; color: green;">SEARCH</h5>
        <br><br><br>
    </div>
  </div>

  <div class="container">
    <div class="row">
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
    <h4 style="font-family: 'Times New Roman', Times, serif;">Search for Products:   
        <input class="searchinput" name="searchItem" placeholder="Search" type="search" style="margin-left: 15px; font-family: 'Times New Roman', Times, serif;" >
        <button type="submit" class="btn btn-success me-3" name="search" style="border-radius: 10px;">
            <i class="bi bi-search"></i>
        </button>
    </h4>
    <br>
  </form>
  </div>
</div>
  <hr style="border-top: 1px solid black;"><br>

<div class="container">
  <div class="row">
  <?php
    require_once('dbconn.php');

    if (isset($_POST['search']) && !empty($_POST['searchItem'])) {
      $term = $_POST['searchItem'];

      include('backend/loginsearchexample.php');

      if (count($search_result_set) == 0)
        echo '<h4>No results found for your search term "' . $term . '"</h4>';
      

    } else {

      include('backend/logindisplayBevSearch.php');

    }

    ?>
  <br>  
 </div>
 </div>
 </div>
 <br><br>
 <!-- Footer -->
 <?php
      include('footer.php')
  ?>
</body>
</html>