<?php
session_start();
require_once('dbconn.php');
$regID = $_SESSION['regID'];
$sql = "SELECT SUM(ubaskettotal) AS total FROM userorders where regID = :regID";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':regID', $regID);
$stmt->execute();
$total = $stmt->fetchColumn();

echo '$ ' . ($total ? $total : '0');

$conn = null;
?>

