<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <link rel="stylesheet" href="Allcss/Design.css">
    <script defer src="active_link.js"></script>

</head>
<body>
       <!-- For Navar -->
      <?php
      include('Navar.php')
      ?>
    </div><br><br>
   
     <!-- All Codes Here -->
      <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="zoom1">
                    <img src="img/volka-removebg-preview.png" class="img-fluid" alt="front img" style="padding-top: 20px; padding-left: 25px; height: 650px; margin-top: 80px;"/>
                </div> 
            </div>
            <div class="col-md-6" style="text-align: justify; margin-top: 13px;">
                    <p>The <strong>Drink Delight</strong> store is a unique destination for beverage lovers who are looking 
                        for a truly customizable and personalized experience. Located in the heart of the city, 
                        the store offers a wide range of drinks and flavors, all made fresh and on-demand using the 
                        innovative Drink Delight system. In addition to the customizable drinks, the Drink Delight store also offers a range of pre-made options for those who prefer a more traditional approach. 
                        These drinks are made fresh daily and are carefully curated to ensure maximum flavor and quality.</p>
            </div><br><br>
            <div class="row">
                <div class="zoom2">
                    <center>
                        <img src="img/wines-removebg-preview.png" alt="wines" class="img-fluid" style="width: 700px; height: 50%;">
                    </center>
                   
                </div>
            </div>
            <div class="row" style="text-align: justify;">
                <p class="card-text">At the <strong>Drink Delight</strong> store, customers are invited to create their own drinks, 
                    choosing from a variety of bases, flavors, and customizations. 
                    Whether it's a hot or cold beverage, coffee, tea, juice, soda, or something in between, 
                    customers can use the state-of-the-art touchscreen interface to craft their perfect drink. 
                    They can choose their preferred sweetness level, temperature, 
                    and even add extra shots of flavor or caffeine to create a truly unique and personalized beverage.<br><br>
                    The store's expert staff is always on hand to help customers navigate the system and provide recommendations based on their tastes and preferences. 
                    They are passionate about creating a welcoming and inclusive environment that encourages customers to experiment with new flavors and combinations.
                </p>
            </div>
        </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      include('footer.php')
      ?>
</body>
</html>