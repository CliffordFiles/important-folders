<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.5/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.5/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <link rel="stylesheet" href="Allcss/Design.css">
    <link rel="stylesheet" href="Allcss/tabledesign.css"> 
    <script defer src="active_link.js"></script>

</head>
<body>
      <!-- For Navar -->
      <?php
      include('NavarLogin.php')
      ?><br><br><br><br><br>
          <center><h2 style="font-weight: bolder; color: green; margin-top: 15px;">SHOPPING BASKET</h2></center>
              <div class="container">
                <div style="display: flex; justify-content: flex-end;">
                <button class="btn btn-outline-danger" onclick="confirmDelete();" style="width: 150px; margin-bottom: 15px;">Delete All</button>
                <script>
                  function confirmDelete() {
                  // Send a request to the server to check if the basket is empty
                  var xhr = new XMLHttpRequest();
                  xhr.open('GET', 'logincheckbasket.php', true);
                  xhr.onload = function() {
                    if (xhr.status == 200 && xhr.responseText === 'empty') {
                      swal({
                        title: "Basket is Empty!",
                        text: "You cant Delete if the Basket is Empty!  ",
                        icon: "warning",
                        button: "Close",
                      });
                    } else {
                      swal({
                        title: "Are you sure?",
                        text: "This will Delete All Records!",
                        icon: "warning",
                        buttons: ["Cancel", "Yes, Delete All"],
                        dangerMode: true,
                      })
                      .then((willDelete) => {
                        if (willDelete) {
                          window.location.href = "loginbasketalldelete.php";
                        }
                      });
                    }
                  };
                  xhr.send();
                }
                </script>
                </div>

<?php
  include('shopbasket3.php')
?>

<div class="container">
  <div class="row">
    <div class="table-responsive">
      <table class="table table-striped table-hover " style="text-align:center;">
        <thead style="background-color: #002d72;">
          <tr>
            <td><h3 style="color: white;">Grand Total: </h3></td>
            <td><h3 style="color: white;" id="gtotal"></h3></td>
            <td>
            <button class="btn btn-outline-light" href="#!" type="submit" onclick="confirmPurchase();"> Make Purchase</button>
            <script>
              function confirmPurchase() {
                // Send a request to the server to check if the basket is empty
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'logincheckbasket.php', true);
                xhr.onload = function() {
                  if (xhr.status == 200 && xhr.responseText === 'empty') {
                    swal({
                      title: "Basket is Empty!",
                      text: "Please add items to your basket before making a purchase.",
                      icon: "warning",
                      button: "Close",
                    });
                  } else {
                    // Show confirmation dialog using SweetAlert
                    swal({
                      title: "Confirm Purchase",
                      text: "Are you sure you want to purchase these items?",
                      icon: "info",
                      buttons: ["Cancel", "Purchase"],
                    }).then((willPurchase) => {
                      if (willPurchase) {   
                        // Show success message and redirect to loginmakepurchase.php
                        swal({
                          title: "Ordered Successfully!",
                          text: "You can view your order at the Order History",
                          icon: "success",
                          button: "Proceed",
                        }).then((willInsert) => {
                          if (willInsert) {
                            window.location.href = "loginmakepurchase.php";
                          }
                        });
                      }
                    });
                  }
                };
                xhr.send();
              }
            </script>
          </td>
          </tr>
          <script>
            // Get the gtotal element
            var gtotal = document.getElementById('gtotal');

            // Send a request to the server to get the sum of baskettotal values
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'loginbaskettotal.php', true);
            xhr.onload = function() {
              if (xhr.status == 200) {
                // Update the gtotal element with the sum of baskettotal values
                gtotal.textContent = xhr.responseText;
              }
            };
            xhr.send();
          </script>
        </thead>
      </table>
    </div>
  </div>
</div>
 <!-- Footer -->
 <?php
      include('footer.php');
 ?>
</body>
</html>    
