<?php
session_start();
require_once('dbconn.php');

if (isset($_POST['submit'])) {
    $new_email = $_POST['new_email'];
    $new_username = $_POST['new_username'];

    if (empty($_POST['new_email']) && empty($_POST['new_username']) && empty($_FILES['new_image']['name']) && empty($_POST['new_first_name']) && empty($_POST['new_last_name']) && empty($_POST['new_address']) && empty($_POST['new_number'])) 
    {
        echo "<script>alert('All Fields are Empty, Nothing to Edit!');window.location.href='accountedit.php'</script>";

    } else {

        $stmt = $conn->prepare('SELECT COUNT(*) FROM registration WHERE email = ?');
        $stmt->execute([$new_email]);
        $email_count = $stmt->fetchColumn();

        $stmt = $conn->prepare('SELECT COUNT(*) FROM registration WHERE username = ?');
        $stmt->execute([$new_username]);
        $username_count = $stmt->fetchColumn();

         if ($email_count > 0 && $username_count > 0) {
            echo "<script>alert('Email and username already exist. Please try again.');window.location.href='accountedit.php'</script>";
        } else if ($email_count > 0) {
            echo "<script>alert('Email already exists. Please try again.');window.location.href='accountedit.php'</script>";
        } else if ($username_count > 0) {
            echo "<script>alert('Username already exists. Please try again.');window.location.href='accountedit.php'</script>";
        }else {
        
                if (isset($_SESSION['regID'])) {
                    $regID = $_SESSION['regID'];
                    $new_image = $_FILES['new_image']['name'];
                    $temp_image = $_FILES['new_image']['tmp_name'];

                    if (!empty($_FILES['new_image']['name'])) {
                        $new_image = file_get_contents($_FILES['new_image']['tmp_name']);
                    
                    } else {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_image = $row['profile'];
                    }

                    $new_first_name = $_POST['new_first_name'];
                    $new_last_name = $_POST['new_last_name'];
                    $new_email = $_POST['new_email'];
                    $new_username = $_POST['new_username'];
                    $new_address = $_POST['new_address'];
                    $new_number = $_POST['new_number'];

                    if (empty($new_first_name)) {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_first_name = $row['firstname'];
                    }

                    if (empty($new_last_name)) {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_last_name = $row['lastname'];
                    }

                    if (empty($new_email)) {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_email = $row['email'];
                    }

                    if (empty($new_username)) {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_username = $row['username'];
                    }

                    if (empty($new_address)) {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_address = $row['address'];
                    }

                    if (empty($new_number)) {
                        $stmt = $conn->prepare("SELECT * FROM registration WHERE regID = ?");
                        $stmt->execute([$regID]);
                        $row = $stmt->fetch();
                        $new_number = $row['mobilenumber'];
                        
                        } elseif (!preg_match("/^09\d{9}$/", $new_number)) {
                        echo "<script>alert('Phone number format is wrong. Please enter a valid number.');window.location.href='accountedit.php'</script>";
                    }  
                    try {
                        $sql = "UPDATE registration SET profile=:image, firstname=:firstname, lastname=:lastname, email=:email, username=:username, address=:address, mobilenumber=:mobilenumber WHERE regID = :regID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindParam(':image', $new_image, PDO::PARAM_LOB);
                        $stmt->bindParam(':firstname', $new_first_name);
                        $stmt->bindParam(':lastname', $new_last_name);
                        $stmt->bindParam(':email', $new_email);
                        $stmt->bindParam(':username', $new_username);
                        $stmt->bindParam(':address', $new_address);
                        $stmt->bindParam(':mobilenumber', $new_number);
                        $stmt->bindParam(':regID', $regID);
                        $stmt->execute();
                
                        $_SESSION['username'] = $new_username;
                
                            echo "<script>alert('Update Successful!');window.location.href='loginaccsetting.php'</script>";
                            } catch(PDOException $e) {
                            echo "Error: " . $e->getMessage();
                            }
                        }
                    }
                 }
            }
?>
