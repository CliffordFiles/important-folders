<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet" href="Allcss/tabledesign.css">
    <script defer src="active_link.js"></script>

</head>
<body>
<!-- For Navar -->
<?php
      include('NavarLogin.php');
      ?>
      <br><br><br><br><br>

<?php
  require_once('dbconn.php');
  $regID = $_SESSION['regID'];
  $stmt = $conn->prepare("SELECT * FROM registration where regID = :regID");
  $stmt->bindParam(':regID', $regID);
  $stmt->execute();
  $row = $stmt->fetch(); // fetch a single row
  
  if ($row) { // check if the query returned any results
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card shadow-lg p-3 mb-5 bg-white rounded" style="border-radius: 30px; box-shadow: 0px 0px 10px 3px rgba(52, 211, 153, 0.7);">
                <div class="card-body text-center">
                <form action="accountchangepassword_db.php?regID=<?php echo $regID; ?>" method="post" enctype="multipart/form-data"> 
                <p style="font-size: 18px; font-family: Times New Roman, Times, serif;">Note: Password must be at least 8 characters long, 
                1 uppercase letter, 1 alphanumeric character and 1 special character</p> 
                <hr> 

                        <div class="mb-3">
                            <label for="password" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Enter a new Password</label>
                            <input type="password" class="form-control" id="password" name="password" style="border-radius: 10px;" required>
                        </div>

                        <div class="mb-3">
                            <label for="password2" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Confirm new Password</label>
                            <input type="password" class="form-control" id="password2" name="password2" style="border-radius: 10px;" required>
                        </div>
                        <br>

                        <button type="submit" class="btn btn-primary" name="submitnewpassword" style="margin-top: 10px; width: 155px;"><i class="bi bi-save2-fill"></i> &nbsp;&nbsp;Enter</button>
                    </form>

                    <a href="accounteditpassword.php">
                    <button type="submit" class="btn btn-primary" name="submit" style="margin-top: 10px; width: 155px;" ><i class="bi bi-x-circle"></i> &nbsp;Back</button></a>
                </div>
            </div>
        </div>
    </div>
</div>
</div><br><br><br>
<?php } ?> 

<?php
    include('footer.php')
?>
</body>
</html>