<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet" href="Allcss/tabledesign.css">
    <script defer src="active_link.js"></script>

</head>
<body>
<!-- For Navar -->
      <?php
      include('NavarLogin.php');
      ?>
      <br><br><br>
      
<?php
  require_once('dbconn.php');
  $regID = $_SESSION['regID'];
  $stmt = $conn->prepare("SELECT * FROM registration where regID = :regID");
  $stmt->bindParam(':regID', $regID);
  $stmt->execute();
  $row = $stmt->fetch(); // fetch a single row
  
  if ($row) { // check if the query returned any results
?>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="card shadow-lg p-3 mb-5 bg-white rounded" style="border-radius: 30px; box-shadow: 0px 0px 10px 3px rgba(52, 211, 153, 0.7); border-radius: 20px;  ">
          <div class="card-body text-center"> 
            <form action="accountedit.php?bevID=<?php echo $regID; ?>" method="post" enctype="multipart/form-data">
            <div class="mb-3">
              <?php
                  $img_data = base64_encode($row['profile']);
                  $img_type = 'image/jpeg'; 
              ?>
              <img src="data:<?php echo $img_type; ?>;base64,<?php echo $img_data; ?>"class="rounded-circle" width="150" height="150">
            </div>
          <hr>
    
          <div class="mb-3">
            <label for="first-name" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">First Name</label>
            <input type="text" class="form-control" id="first-name" style="border-radius: 10px;"  value="<?php echo $row['firstname']; ?>" readonly>
          </div>
 
          <div class="mb-3">
            <label for="last-name" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Last Name</label>
            <input type="text" class="form-control" id="last-name"  style="border-radius: 10px;"  value="<?php echo $row['lastname'];?>"readonly>
          </div>

          <div class="mb-3">
            <label for="newemail" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Email</label>
            <input type="email" class="form-control" id="email" name="email" style="border-radius: 10px;" value="<?php echo $row['email'];?>"readonly>
          </div>

          <div class="mb-3">
            <label for="newusername" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Username</label>
            <input type="text" class="form-control" id="newusername" name="newusername" style="border-radius: 10px;" value="<?php echo $row['username'];?>"readonly>
          </div>

          <div class="mb-3">
            <label for="newaddress" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Address</label>
            <input type="text" class="form-control" id="newaddress" name="newaddress" style="border-radius: 10px;" value="<?php echo $row['address'];?>"readonly>
          </div>

          <div class="mb-3">
            <label for="newnumber" class="form-label" style="font-family: Times New Roman, Times, serif; font-size: 20px;">Phone Number</label>
            <input type="text" class="form-control" id="newnumber" name="newnumber" style="border-radius: 10px;" value="<?php echo $row['mobilenumber'];?>"readonly>
          </div><br>
          
          <button type="submit" class="btn btn-primary" style="border-radius: 10px; width: 175px;"><i class="bi bi-pencil"></i> Edit Profile</button>
          </form>
          <div>
            <form action="accounteditpassword.php?bevID=<?php echo $regID; ?>" method="post">
          <button type="submit" class="btn btn-primary" style="margin-top: 10px; border-radius: 10px;"><i class="bi bi-key"></i></i>&nbsp; Change Password</button>
            </form>
          </div>
          </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div><br>
<?php } ?>       
      <?php
      include('footer.php')
    ?>
</body>
</html>