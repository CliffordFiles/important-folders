<?php
require_once('dbconn.php');

try {
    $sql = "DELETE FROM basket WHERE basketid = :basketid";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':basketid', $_GET['basketid'], PDO::PARAM_STR);
    $stmt->execute();
    header('Location: ' . $_SERVER['HTTP_REFERER']);
} catch(PDOException $e) {
    echo "ERROR: ". $e->getMessage();
}

$conn = null;
?>
