<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drink Delight: Online Beverage Grocery Shopping</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="Allcss/Allnavar.css">
    <link rel="stylesheet" href="footer.css">
    <script defer src="active_link.js"></script>

</head>
<body>
      <!-- For Navar -->
      <?php
      include('NavarLogin.php')
      ?>
    <br><br><br><br><br><br>
    
  <center><h2 style="font-weight: bolder; color: green;">SOFT DRINKS</h2></center>
  <br>
  
    <!-- Drop Down -->
    <div class="container">
        <div class="row">
          <div class="float-start">
    <div class="btn-group" style="width: 200px;">
        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Soft Drinks
        </button> 
        <div class="dropdown-menu" >
          <a class="dropdown-item" href="loginbeverage_liquor.php">Liquor</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="loginbeverage_juice.php">Juice</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="loginbeverage.php">Beverage</a>
          </div>
        </div>
        </div>
        </div>
      </div>
<br> 

 <!-- Drop Down -->
 <?php
require_once('dbconn.php');

$stmt = $conn->prepare("SELECT * FROM beverage WHERE bevcategory = 'softdrinks'");
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container">
  <div class="row">
    <?php foreach ($results as $row) { ?>
      <div class="col-12 col-md-6 col-lg-4 mb-4">
      <form action="loginmanage_cart.php?redirect=<?php echo basename($_SERVER['PHP_SELF']) ?>" method="POST">
        <div class="card h-100" style="border-radius: 30px; box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.2);">
          <img src='data:image/jpeg;base64,<?php echo base64_encode($row['bevimg']) ?>' alt="<?php echo $row['bevtitle'] ?>" class="card-img-top" width="400" height="400">
          <div class="card-body">
            <center>
            <h5 class="card-title"><?php echo $row['bevtitle'] ?></h5>
            <br>
            <p class="card-text mb-3"><?php echo $row['bevdesc'] ?></p>
            <h5 class="card-text">$<?php echo $row['bevprice'] ?></h5>
            <br>

              <label for="quantity">Quantity:</label>
              <input type="number" id="quantity" name="quantity1" min="1" max="50" style="border-radius: 10px;" value="1">
              <br><br>
              <button href="#!" type="submit" name="Add_To_Cart" class="btn btn-success me-3" style="border-radius: 10px; margin-left: 25px; "><i class="bi bi-basket me-2"></i>Add to Basket</button>
              <input type="hidden" name="Item_Name" value="<?php echo $row['bevtitle'] ?>">
              <input type="hidden" name="Price" value="<?php echo $row['bevprice'] ?>">            
          </div>
          </center>
        </div>
      </div>
      </form>
    <?php } ?>
  </div>
</div>
 <!-- Footer -->
 <?php
      include('footer.php')
    ?>
</body>
</html>